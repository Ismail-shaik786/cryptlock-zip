#!/bin/bash
# ==============================================================================
#  CryptLock — Automated Linux Installer (User & System Mode)
# ==============================================================================
set -e

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${CYAN}============================================================${NC}"
echo -e "${CYAN}  🛡️  CryptLock — Real-Time Ransomware Detection & Recovery${NC}"
echo -e "${CYAN}     Linux Installer${NC}"
echo -e "${CYAN}============================================================${NC}"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Determine installation mode: System-wide (/usr/local/bin) if root/sudo, else User-local (~/.local/bin)
if [ "$EUID" -eq 0 ]; then
    INSTALL_DIR="/usr/local/bin"
    IS_SYSTEM=true
    echo -e "  ${CYAN}⚙  Mode:${NC} System-wide installation (${INSTALL_DIR})"
else
    INSTALL_DIR="$HOME/.local/bin"
    IS_SYSTEM=false
    echo -e "  ${CYAN}⚙  Mode:${NC} User-local installation (${INSTALL_DIR})"
fi

mkdir -p "$INSTALL_DIR"

# 1. Search for .deb package (if running system-wide as root)
DEB_FILE=$(find "$SCRIPT_DIR" -maxdepth 2 -name "*.deb" 2>/dev/null | head -n 1)

if $IS_SYSTEM && [ -n "$DEB_FILE" ] && command -v dpkg >/dev/null 2>&1; then
    echo -e "  ${CYAN}⟳${NC}  Installing Debian package: $(basename "$DEB_FILE")"
    dpkg -i "$DEB_FILE"
    echo ""
    echo -e "  ${GREEN}✔  CryptLock installed system-wide successfully!${NC}"
    echo -e "  Launch anytime by typing: ${GREEN}cryptlock${NC}"
    exit 0
fi

# 2. Search for pre-compiled binary (CryptLock)
CRYPTLOCK_BIN=""
if [ -f "$SCRIPT_DIR/CryptLock" ]; then
    CRYPTLOCK_BIN="$SCRIPT_DIR/CryptLock"
elif [ -f "$SCRIPT_DIR/dist/CryptLock" ]; then
    CRYPTLOCK_BIN="$SCRIPT_DIR/dist/CryptLock"
fi

SIMULATOR_BIN=""
if [ -f "$SCRIPT_DIR/RansomwareSimulator" ]; then
    SIMULATOR_BIN="$SCRIPT_DIR/RansomwareSimulator"
elif [ -f "$SCRIPT_DIR/dist/RansomwareSimulator" ]; then
    SIMULATOR_BIN="$SCRIPT_DIR/dist/RansomwareSimulator"
fi

if [ -n "$CRYPTLOCK_BIN" ]; then
    echo -e "  ${CYAN}⟳${NC}  Copying binary to ${INSTALL_DIR}/cryptlock…"
    
    cp "$CRYPTLOCK_BIN" "$INSTALL_DIR/cryptlock"
    chmod 755 "$INSTALL_DIR/cryptlock"
    
    if [ -n "$SIMULATOR_BIN" ]; then
        cp "$SIMULATOR_BIN" "$INSTALL_DIR/ransomware-simulator"
        chmod 755 "$INSTALL_DIR/ransomware-simulator"
    fi

    # Ensure ~/.local/bin is in PATH for user installation
    if ! $IS_SYSTEM; then
        case ":$PATH:" in
            *":$INSTALL_DIR:"*) ;;
            *)
                echo -e "  ${CYAN}⟳${NC}  Adding ${INSTALL_DIR} to your shell PATH..."
                if [ -f "$HOME/.bashrc" ]; then
                    grep -qF 'export PATH="$HOME/.local/bin:$PATH"' "$HOME/.bashrc" || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
                fi
                if [ -f "$HOME/.zshrc" ]; then
                    grep -qF 'export PATH="$HOME/.local/bin:$PATH"' "$HOME/.zshrc" || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.zshrc"
                fi
                export PATH="$HOME/.local/bin:$PATH"
                ;;
        esac
    fi

    echo ""
    echo -e "  ${GREEN}✔  Installation complete!${NC}"
    echo -e "  No root/sudo password required."
    echo ""
    echo -e "  To launch CryptLock now, run:"
    echo -e "    ${GREEN}cryptlock${NC}"
    if [ -n "$SIMULATOR_BIN" ]; then
        echo -e "    ${GREEN}ransomware-simulator${NC}"
    fi
    echo ""
    exit 0
fi

# 3. Fallback: If no binary is found, try building from source
if [ -f "$SCRIPT_DIR/build.py" ]; then
    echo -e "  ${YELLOW}⚠  Pre-built binary not found. Building executable using Python…${NC}"
    python3 "$SCRIPT_DIR/build.py" --all
    
    if [ -f "$SCRIPT_DIR/dist/CryptLock" ]; then
        cp "$SCRIPT_DIR/dist/CryptLock" "$INSTALL_DIR/cryptlock"
        chmod 755 "$INSTALL_DIR/cryptlock"
        if [ -f "$SCRIPT_DIR/dist/RansomwareSimulator" ]; then
            cp "$SCRIPT_DIR/dist/RansomwareSimulator" "$INSTALL_DIR/ransomware-simulator"
            chmod 755 "$INSTALL_DIR/ransomware-simulator"
        fi
        echo -e "  ${GREEN}✔  Build and installation successful!${NC}"
        echo -e "  Launch by typing: ${GREEN}cryptlock${NC}"
        exit 0
    fi
fi

echo -e "  ${RED}✖  Installation failed: Neither CryptLock binary nor .deb package was found.${NC}"
exit 1
