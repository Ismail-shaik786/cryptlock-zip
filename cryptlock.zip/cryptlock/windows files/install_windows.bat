@echo off
:: ==============================================================================
::  CryptLock — Automated Windows Standalone Installer
:: ==============================================================================
title CryptLock Windows Installer

echo ============================================================
echo   🛡️  CryptLock — Real-Time Ransomware Detection & Recovery
echo      Windows Standalone Installer
echo ============================================================
echo.

set TARGET_DIR=%LOCALAPPDATA%\CryptLock
set SCRIPT_DIR=%~dp0

echo [1/3] Creating installation directory at:
echo       %TARGET_DIR%
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
if not exist "%TARGET_DIR%\backups" mkdir "%TARGET_DIR%\backups"
if not exist "%TARGET_DIR%\logs" mkdir "%TARGET_DIR%\logs"
if not exist "%TARGET_DIR%\reports" mkdir "%TARGET_DIR%\reports"

echo.
echo [2/3] Installing standalone application binaries...

set CRYPTLOCK_EXE=
if exist "%SCRIPT_DIR%CryptLock.exe" set CRYPTLOCK_EXE=%SCRIPT_DIR%CryptLock.exe
if exist "%SCRIPT_DIR%dist\CryptLock.exe" set CRYPTLOCK_EXE=%SCRIPT_DIR%dist\CryptLock.exe

set SIM_EXE=
if exist "%SCRIPT_DIR%RansomwareSimulator.exe" set SIM_EXE=%SCRIPT_DIR%RansomwareSimulator.exe
if exist "%SCRIPT_DIR%dist\RansomwareSimulator.exe" set SIM_EXE=%SCRIPT_DIR%dist\RansomwareSimulator.exe

if not "%CRYPTLOCK_EXE%"=="" (
    echo   Copying pre-compiled binary CryptLock.exe...
    copy /Y "%CRYPTLOCK_EXE%" "%TARGET_DIR%\CryptLock.exe" >nul
    if not "%SIM_EXE%"=="" (
        copy /Y "%SIM_EXE%" "%TARGET_DIR%\RansomwareSimulator.exe" >nul
    )
    goto SETUP_SHORTCUTS
)

:: Fallback if pre-built binary is not found: try source build if build.py exists
if exist "%SCRIPT_DIR%build.py" (
    echo   Pre-built CryptLock.exe not found. Building executable using Python...
    python "%SCRIPT_DIR%build.py" --all
    if exist "%SCRIPT_DIR%dist\CryptLock.exe" (
        copy /Y "%SCRIPT_DIR%dist\CryptLock.exe" "%TARGET_DIR%\CryptLock.exe" >nul
        if exist "%SCRIPT_DIR%dist\RansomwareSimulator.exe" (
            copy /Y "%SCRIPT_DIR%dist\RansomwareSimulator.exe" "%TARGET_DIR%\RansomwareSimulator.exe" >nul
        )
        goto SETUP_SHORTCUTS
    )
)

echo.
echo   [ERROR] Installation failed: CryptLock.exe binary not found.
echo           Please ensure CryptLock.exe or dist\CryptLock.exe is present.
echo.
pause
exit /b 1

:SETUP_SHORTCUTS
copy /Y "%SCRIPT_DIR%README.md" "%TARGET_DIR%\" >nul 2>&1
copy /Y "%SCRIPT_DIR%LICENSE" "%TARGET_DIR%\" >nul 2>&1
copy /Y "%SCRIPT_DIR%USER_MANUAL.md" "%TARGET_DIR%\" >nul 2>&1

echo.
echo [3/3] Creating Desktop launcher shortcuts...

:: Create Desktop Launcher script
set LAUNCHER=%USERPROFILE%\Desktop\CryptLock.bat
echo @echo off > "%LAUNCHER%"
echo title CryptLock - Ransomware Guard >> "%LAUNCHER%"
echo cd /d "%TARGET_DIR%" >> "%LAUNCHER%"
echo CryptLock.exe >> "%LAUNCHER%"

if exist "%TARGET_DIR%\RansomwareSimulator.exe" (
    set SIM_LAUNCHER=%USERPROFILE%\Desktop\CryptLock_Simulator.bat
    echo @echo off > "%SIM_LAUNCHER%"
    echo title CryptLock - Ransomware Simulator >> "%SIM_LAUNCHER%"
    echo cd /d "%TARGET_DIR%" >> "%SIM_LAUNCHER%"
    echo RansomwareSimulator.exe >> "%SIM_LAUNCHER%"
)

echo.
echo ============================================================
echo   ✔  WINDOWS INSTALLATION COMPLETE!
echo ============================================================
echo.
echo   Installed location : %TARGET_DIR%\CryptLock.exe
echo   No Python or source code required.
echo.
echo   Desktop shortcuts created:
echo   - CryptLock.bat
if exist "%TARGET_DIR%\RansomwareSimulator.exe" (
    echo   - CryptLock_Simulator.bat
)
echo.
pause
